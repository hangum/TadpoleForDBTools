package intrinsic.flash.text;

public class TextField {

	/** Accessors */
	public String restrict;
	public int caretIndex;
	public int maxScrollV;
	public int bottomScrollV;
	public int scrollV;
	public String gridFitType;
	public boolean mouseWheelEnabled;
	public boolean border;
//	public intrinsic.flash.display.Menu contextMenu;
	public double thickness;
	public boolean background;
	public String text;
	public int selectionBeginIndex;
	public int borderColor;
	public boolean useRichTextClipboard;
	public double sharpness;
	public int textColor;
	public double textWidth;
	public boolean selectable;
	public boolean alwaysShowSelection;
	public double textHeight;
	public String autoSize;
	public boolean multiline;
	public int backgroundColor;
	public boolean wordWrap;
	public boolean embedFonts;
	public int selectionEndIndex;
	public boolean displayAsPassword;
	public int maxChars;
	public boolean condenseWhite;
	public int length;
	public String antiAliasType;
	public String selectedText;
//	public intrinsic.flash.text.StyleSheet styleSheet;
	public String type;
	public int maxScrollH;
//	public intrinsic.flash.text.TextFormat defaultTextFormat;
	public int numLines;
	public int scrollH;
	public String htmlText;

	/** Variables */

	/** Constants */

	/** Class Accessors */

	/** Class variables */

/** Contructors */
public TextField() {
}


/** Static Methods */

/** Methods */
public void insertXMLText(int arg0, int arg1, String arg2) {}
public void insertXMLText(int arg0, int arg1, String arg2, boolean arg3) {}
public  int getFirstCharInParagraph(int arg0) {return 0;}
public  void replaceText(int arg0, int arg1, String arg2) {}
public  void replaceSelectedText(String arg0) {}
public  String getXMLText() {return null;}
public  String getXMLText(int arg0) {return null;}
public  String getXMLText(int arg0, int arg1) {return null;}
public  String getRawText() {return null;}
public  String getLineText(int arg0) {return null;}
public  int getLineOffset(int arg0) {return 0;}
public  int getParagraphLength(int arg0) {return 0;}
public  void setSelection(int arg0, int arg1) {}
public  int getLineIndexAtPoint(double arg0, double arg1) {return 0;}
public  int getCharIndexAtPoint(double arg0, double arg1) {return 0;}
public  int getLineLength(int arg0) {return 0;}
public  void appendText(String arg0) {}
public  int getLineIndexOfChar(int arg0) {return 0;}

}
