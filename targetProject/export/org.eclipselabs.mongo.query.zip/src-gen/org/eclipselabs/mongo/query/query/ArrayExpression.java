/**
 */
package org.eclipselabs.mongo.query.query;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Array Expression</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see org.eclipselabs.mongo.query.query.QueryPackage#getArrayExpression()
 * @model
 * @generated
 */
public interface ArrayExpression extends EObject
{
} // ArrayExpression
